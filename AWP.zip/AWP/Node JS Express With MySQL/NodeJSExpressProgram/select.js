const http = require('http');
const mysql = require('mysql');

const con = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: '',
  database: 'mydb',

});

//html string that will be send to browser
var webpage ='<html><head><title>Node.js MySQL Select</title></head><body><h1>Node.js MySQL Select</h1>{${table}}</body></html>';

//sets and returns html table with results from sql select
//Receives sql query and callback function to return the table
function setResHtml(sql,cb){
  //con.connect(function(err, con){
   // if(err) throw err;

    con.query(sql, function(err, res, cols){
      if(err) throw err;

      var table =''; //to store html table

      //create html table with data from res.
      for(var i=0; i<res.length; i++){
        table +='<tr><td>'+ (i+1) +'</td><td>'+ res[i].name +'</td><td>'+ res[i].address +'</td></tr>';
      }
      table ='<table border="1"><tr><th>Sr.</th><th>Name</th><th>Address</th></tr>'+ table +'</table>';

     // con.close(); //Done with mysql connection

      return cb(table);
    });
  //});
}

let sql ='SELECT name, address FROM customer';
let recsql="";

//create the server for browser access
const server = http.createServer(function(req, res){
  setResHtml(sql, function(recsql){
    webpage = webpage.replace('{${table}}', recsql);
    res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});
    res.write(webpage, 'utf-8');
    res.end();
  });
});

server.listen(3000, function(){
  console.log('Server running');
});
