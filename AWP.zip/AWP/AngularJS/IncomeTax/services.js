myApp.service('tax', function() { 

 this.myFunc = function (income,deductions) { 

 net_income=income-deductions-50000; 

 if(net_income<=250000){ 

 return 0; 

 } 

 else if(net_income<=500000){ 

return net_income*0.05 

 } 

 else if(net_income<=1000000){ 

 return net_income*0.2 

 } 

 else if(net_income>1000000){ 

 return net_income*0.3 

 } 

 } 

}); 