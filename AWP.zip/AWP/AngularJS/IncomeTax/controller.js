myApp.controller("myCtrl",function($scope,tax){ 

 $scope.userDetail=function(){ 

 $scope.display = true; 

 $scope.tax_payable = tax.myFunc($scope.grossinc,$scope.deduc); 

 }; 

 $scope.reset = function(){ 

 $scope.name=""; 

 $scope.grossinc=""; 

 $scope.deduc=""; 

 $scope.display=false; 

 $scope.myForm.$setPristine(); 

 } 

  

}); 