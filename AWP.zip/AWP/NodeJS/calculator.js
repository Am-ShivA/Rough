exports.add = function (a, b) {
    return a+b;
}; 
exports.subtract = function (a, b) {
    return a-b;
}; 
exports.multiply = function (a, b) {
    return a*b;
};