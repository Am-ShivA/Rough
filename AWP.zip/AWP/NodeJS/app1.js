var log=require('Log1');
log.info("This is information Msg");
log.warning("This is warning Msg");
log.Error("This is Error Msg");