<?php
$data=$_REQUEST['datavalue'];
$a=array('MachineLearning','DataAnalytics','PythonFundamentals');
$b=array('WebDevelopment','AdvancePython','DataStructurAndAlgorithm');
if($data=="BTech")
{
	foreach($a as $aone)
	{
		echo"<option>$aone</option>";
	}
}
if($data=="MBATech")
{
	foreach($b as $aone)
	{
		echo"<option>$aone</option>";
	}
}
?>
