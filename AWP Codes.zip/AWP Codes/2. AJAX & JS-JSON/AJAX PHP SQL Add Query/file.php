<?php
    $mydata = $_REQUEST['key'];
    // we have delimiters as commas in the recevied data from HTML to PHP so we need to use this function 
    // Data is not really an array, it's just in text/string form 
    $realdata = explode(",",$mydata);
    
    $con = new mysqli("localhost", "root", "", "master");
    if (!$con){
        die("Connection Failed");
    }
    else{
        $sqlstr = "INSERT INTO EMPLOYEE(empid, empname, dept) VALUES ('$realdata[0]','$realdata[1]','$realdata[2]')";
        if (mysqli_query($con, $sqlstr)){
            echo "Record has been inserted";
        }
        else{
            echo "Record Has Not been inserted"
        }
    }

?>