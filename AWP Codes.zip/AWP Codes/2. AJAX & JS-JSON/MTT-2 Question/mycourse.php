<?php
$mydata = $_REQUEST['datavalue'];
$a = array("ML","WP","XML");
$b = array("BigData","BDMS","PYTHON");
if($mydata == "BTECH")
{
    foreach($a as $x)
    {
        echo "<option>".$x."</option>";
    }
}
if($mydata == "MBA-TECH")
{
    foreach($b as $x)
    {
        echo "<option>".$x."</option>";
    }
}
?>