<?php
 
$data = $_REQUEST['key']; //It is not an array!
$URLData = explode(",",$data);

$connect = new mysqli("localhost","root","","sql13sepclass"); //url,username,db name

if(!$connect) {
    die("Connection Failed".mysqli_connect_error());
}


$sqlstr = "INSERT INTO program values ('$URLData[0]','$URLData[1]','$URLData[2]','$URLData[3]')";

if(mysqli_query($connect,$sqlstr))
{
    echo "RECORD INSERTED " .($URLData[0].$URLData[1].$URLData[2].$URLData[3]);
}
?>