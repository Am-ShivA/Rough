<?php
$con = new mysqli("localhost", "root", "", "master");   // url, username, pass, name of DB
// table customer

if (!$con){
    die("connection failed" + .mysqli_connect_error);
}
else{
    $str = "SELECT * FROM customer";
    $record = mysqli_query($con, $str); // is an array 
    while ($row = mysqli_fetch_array($record)){
        echo $row[0].$row[1].$row[2]."<br>" ;               // or mention column name instead of [0]        // br tag, each row contain a single record
    }
}
mysqli_close($con);
?>


<!-- the functions which are used to run  
//mtt2 2 marks questions
mysqli - to make a database connection with the server, it takes 4 params: name of server, username, password, dbname
mysqli_query - this method is used to run the sql query on database. It takes 2 params, a connection object and an SQL Query. This method returns a record set array 
mysqli_fetch_array - this method is used to  fetch up a set of tuples from the given record set. 
mysqli_close - closes the connection on DB. 
-->

