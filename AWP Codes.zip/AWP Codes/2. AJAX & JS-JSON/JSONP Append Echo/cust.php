<?php
    $myJSON='{"name":"Smith", "age":32, "country":"US"}';
    echo "MyFunc(".$myJSON.")";
?>