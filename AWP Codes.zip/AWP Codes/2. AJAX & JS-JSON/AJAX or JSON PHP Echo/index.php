<?php

$my = array("Mike", "Smith", "Paul");

//to convert the array into JSON format

$obj=JSON_encode($my);

// to send response we use the echo method 

echo $obj;

?>