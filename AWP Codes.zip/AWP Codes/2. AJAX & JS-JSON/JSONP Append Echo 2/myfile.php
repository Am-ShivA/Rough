<?php
    $myJSON='[{"author":"J K Rowling","age":32,"country":"US"},{"author":"Mark Manson","age":46,"country":"US"},{"author":"William Stallings","age":46,"country":"US"}]';
    echo "MyFunc(".$myJSON.")";
?>