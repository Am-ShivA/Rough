<?php
    $mydata = $_REQUEST['datavalue'];
    $a = array("Machine Learning", "Web Program", "XML");
    $b = array("Big Data", "Database Management", "HCI");
    if ($mydata == "BTech"){
        foreach($a as $x){
            echo "<option> $x </option>";
        }
    }
    if ($mydata == "MBATech"){
        foreach($b as $x){
            echo "<option> $x </option>";
        }   
    }
?>