<?php
    $myJson='[{"name":"Physics", "author":"Mark Manson"},{"name":"Chemistry", "author":"Jane Janet"},{"name":"Mathematics", "author":"Robert Downey Jr."},{"name":"COA", "author":"William Stallings"}]';
    echo "$myJson"

?>