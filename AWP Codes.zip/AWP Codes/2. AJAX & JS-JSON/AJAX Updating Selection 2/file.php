<?php
$data=$_REQUEST['datavalue'];
$a=array('Machine Learning','Advance Web Programming','Python','Linux');
$b=array('Management','Accounts','PEM');

if($data=="Btech")
{
  foreach($a as $x)
  {
      echo"<option>$x</option>";
    }
}
if($data=="MBATech")
{
  foreach($b as $x)
  {
    echo"<option>$x</option>";
  }
}
?>