const express = require('express');
var bodyparser = require('body-parser');

var app = express();
var server = app.listen(3005,function(){
    var port = server.address().port;
    console.log("Server running at port " + port);
});
var urlp = bodyparser.urlencoded({extended: false});

app.get('/record', function(req, res){
    res.sendFile(__dirname + '\\index.html');
    console.log(__dirname + '\\index.html');
});

app.post('/avg', urlp, function(req, res){
    // urlp will have all the parameters of this body. 
    console.log('Got Body ' , req.body);
    var roll = req.body.t1;
    var name = req.body.t2;
    var awp = parseInt(req.body.t3);
    var os = parseInt(req.body.t4);
    var total = (awp + os);
    var average = total/2;
    res.send("Roll Number is " + roll + " <br> Name is " + name + " <br> Average is " + average);
});