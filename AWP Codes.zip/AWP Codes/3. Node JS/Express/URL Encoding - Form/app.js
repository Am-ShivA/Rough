const express = require('express');
var bodyParser = require('body-parser')
const app = express();
  
var urlencodedParser = bodyParser.urlencoded({ extended: false })

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.post('/', urlencodedParser, (req, res) => {
    console.log('Got body:', req.body);
	var roll_number= req.body.roll_number;
	var name= req.body.name;
	var marks_1= req.body.marks_1;
	var marks_2= req.body.marks_2;
	var marks_3= req.body.marks_3;
  var percentage = (100 * (parseInt(marks_1) +parseInt(marks_2) +parseInt(marks_3))) / 300;
    res.send("Roll Number" + roll_number +" <br> name: "+ name +"<br> Marks 1 "+ marks_1 + " <br> Marks 2 " + marks_2 + " <br> Marks 3 " + marks_3 + " <br> Percentage " + percentage);
});

app.listen(3000);
