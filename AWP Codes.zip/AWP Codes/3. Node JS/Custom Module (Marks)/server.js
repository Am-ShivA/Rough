var NityoModule=require('./file.js');
var a=40, b=20;
console.log("Addition=" + NityoModule.add(a,b));
console.log("Multiplication=" + NityoModule.mul(a,b));
console.log("Subtraction=" + NityoModule.sub(a,b));
console.log("Division=" + NityoModule.div(a,b));
console.log("Modulus=" + NityoModule.mod(a,b));
console.log("Multiplication=" + NityoModule.mul(a,b));