var my_module=module.exports={};
my_module.add=function(a,b){
return a+b;
};
my_module.mul=function(a,b){
return a*b;
};
my_module.sub=function(a,b){
return a-b;
};
my_module.div=function(a,b){
return a/b;
};
my_module.mod=function(a,b){
return a%b;
};
