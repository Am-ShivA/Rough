var events = require('events');
var eventEmitter = new events.EventEmitter();

//Event handler
var show = () => {
    console.log('I hear a screame!');
}

//Assign handler to the event emitter.
eventEmitter.on('screame', show);

eventEmitter.emit('screame');
