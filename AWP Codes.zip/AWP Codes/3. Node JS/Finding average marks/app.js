const bodyParser = require('body-parser');
const express = require('express');
const app = express();
var urlencoded = bodyParser.urlencoded({extended:false});
