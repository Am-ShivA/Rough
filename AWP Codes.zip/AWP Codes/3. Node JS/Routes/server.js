// use npm install express first.
const express = require('express');
var app = express();

app.get('/', function(req,res){
    res.send("Home page access");
});
app.get('/rahul', function(req,res){
    res.send("Rahul page access");
});
app.get('/ab*cd', function(req,res){
    res.send("AB CD");
});
app.delete('/customer_del', function(req,res){
    res.send("Resource Deleted");
});

var server = app.listen(5000, function(){
    // var port = server.address.port();
    console.log("Server Is Now Running my boy :) ");
});