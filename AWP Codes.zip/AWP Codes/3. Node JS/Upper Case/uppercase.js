var uc = require('upper-case');

var str = "nityoday";


console.log(uc.upperCase(str));