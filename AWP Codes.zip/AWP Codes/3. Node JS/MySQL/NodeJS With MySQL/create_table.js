var mysql = require('mysql');
var con = mysql.createConnection(
    {host:"localhost", 
    user:"root",
    password:"",
    database: "nityo_db"
    });
con.connect(function(err){
    if (err) throw err;
    console.log("Connected");
    var sql = "CREATE TABLE CUSTOMER(name varchar(30), company varchar(20))";
    // var sql = "CREATE TABLE employee(id varchar(30), name varchar(20), post varchar(30), salary varchar(30))";
    con.query(sql, function(err,result){
        if (err) throw err;
        console.log("Table is created");
    });
});