//  did not write code. check practical 10. 
