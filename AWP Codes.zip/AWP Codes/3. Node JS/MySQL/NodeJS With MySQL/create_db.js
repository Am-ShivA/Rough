/*
Steps:
1. install npm with npm install msql
2. After including it, create a connection variable
3. Connect the database
*/
var mysql = require('mysql');
var con = mysql.createConnection(
    {host:"localhost", 
    user:"root",
    password:"",
    });

con.connect(function(err){
    if (err) throw err;
    console.log("Connected");
    con.query("CREATE DATABASE Demo1", function(err, result){
        if (err) throw err;
        console.log("Database Created, result is " + result);
    });
});