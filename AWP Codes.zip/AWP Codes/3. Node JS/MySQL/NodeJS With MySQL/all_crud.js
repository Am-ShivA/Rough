const express = require('express');
var bodyparser = require('body-parser');
var mysql = require('mysql');
var url = require("url");

var conn=mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "",
    database : "nityo_db"
});

var app = express();
var server = app.listen(3005,function(){
    var port = server.address().port;
    console.log("Server running at port " + port);
});
var urlp = bodyparser.urlencoded({extended: false});

app.get('/', function(req, res){
    res.sendFile(__dirname + '\\all_crud.html');
});

app.post('/submit', urlp, function(req,res){
    console.log("The fields from the body tag are: ");
    console.log(req.body);
    var roll = req.body.roll;
    var name = req.body.name;
    var t1marks = parseInt(req.body.t1marks);
    var t2marks = parseInt(req.body.t2marks);
    var t3marks = parseInt(req.body.t3marks);
    var percentage = (100*(t1marks+t2marks+t3marks))/30;
    
    if (req.body.crud == 'delete'){
        var queryString="DELETE from nityoday_table where roll = '"+roll+"'";
        conn.query(queryString, function(error,data,fields){
            if(error){
                throw error;
            }
            else{
                console.log("Success for deleting query");
                res.write("Deleting success");
                res.end();
            }
        });
        
    }
    if (req.body.crud == 'update'){
        var queryString="UPDATE nityoday_table SET name = '"+name+"', roll = '"+roll+"', OS = '"+t1marks+"', AWP = '"+t2marks+"', SE = '"+t3marks+"', percentage='"+percentage+"' WHERE roll = '"+roll+"'";
        conn.query(queryString, function(error,data,fields){
            if(error){
                throw error;
            }
            else{
                console.log("Success for updating query");
                res.write("Updation success");
                res.end();
            }
        });
    }
    if (req.body.crud == 'add'){
        var queryString="insert into nityoday_table values('"+roll+"','"+name+"','"+t1marks+"','"+t2marks+"','"+t3marks+"', '"+percentage+"')";
        
        conn.query(queryString, function(error,data){
            if(error){
                throw error;
            }
            else{
                console.log("success for adding query");
                res.write("Insertion success");
                res.end();
            }
        });
    }
    if (req.body.crud == 'display'){
        var queryString="SELECT * FROM nityoday_table";
        conn.query(queryString, function(error,data){
            if(error){
                throw error;
            }
            else{
                txt = "";
                txt += "<h1> Nityoday Tekchandani | N205 | 70472019113 | MBA Tech CE B1 </h1>"
                txt += "<table style='border: 1px solid; background-color: black; color: yellow;'>";
                txt += "<tr style='border: 1px solid;'>";
                txt += "<th>Roll Number</th>"
                txt += "<th> Name </th>"
                txt += "<th>OS Marks</th><th>AWP Marks</th><th>SE Marks</th><th>Percentage</th>";
                for (var i=0; i<data.length; i++){
                    txt += "<tr style='border: 1px solid;'> <td style='border: 1px solid;'>" + data[i].roll + "</td>";
                    txt += "<td style='border: 1px solid;' >" + data[i].name + "</td>"
                    txt += "<td style='border: 1px solid;' >" + data[i].OS + "</td>"
                    txt += "<td style='border: 1px solid;' >" + data[i].AWP + "</td>"
                    txt += "<td style='border: 1px solid;' >" + data[i].SE + "</td>"
                    txt += "<td style='border: 1px solid;' >" + data[i].percentage + "</td>"
                }
                txt += "</table>";
                res.write(txt);
                res.end();
                console.log("success for displaying");
            }
        });
    }
});
    