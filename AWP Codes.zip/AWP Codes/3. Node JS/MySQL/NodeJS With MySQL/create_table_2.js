var mysql = require('mysql');
//  Nityoday Tekchandani | N205 | 70472019113
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "nityo_db"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");

  var sql = "CREATE TABLE customers (name VARCHAR(255), address VARCHAR(255))";

  // var sql = "CREATE TABLE nityoday_table (roll VARCHAR(255), name VARCHAR(255), OS VARCHAR(255), AWP VARCHAR(255), SE VARCHAR(255), percentage VARCHAR(255))";
  // was used for other code. 
  
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table created");
  });
});
