var url = require("url");
const express = require('express');
var bodyParser = require('body-parser');
var mysql = require('mysql');
var conn=mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "",
    database : "nityo_db"
});
const app = express();
var urlencodedParser = bodyParser.urlencoded({ extended: false })

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/input.html');
});

app.post('/', urlencodedParser, (req, res) => {
    var address=req.body.address;
	var name=req.body.name;

res.writeHead(200, {"Content-Type": "text/html"});

var queryString="insert into customers values('"+name+"','"+address+"')";
conn.query(queryString, function(error,data,fields){
    if(error){
        throw error;
    }
    else{
        console.log("success");
    }
}
)
conn.end();
res.write("Insertion success");
});
app.listen(3000);
console.log("Server has started.");