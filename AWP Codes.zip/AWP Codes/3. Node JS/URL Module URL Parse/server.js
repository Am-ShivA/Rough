var url = require('url');
var adr = 'http://localhost:80/default.htm?year=2020&month=march';
var q = url.parse(adr, true)

console.log(q.query);
console.log(q.host);
console.log(q.search);
console.log(q.pathname);

var qdata = q.query;
console.log(qdata.month);