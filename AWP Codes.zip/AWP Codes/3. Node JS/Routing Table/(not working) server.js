const express = require ('express');
var app = new express();

app.get("/", function(req, res){
    res.send("Home Page");
});

// route for customer display

app.get("/cust_disp", function(req, res){
    res.send("Customer Listening ");
});

app.post("/cust_create", function(req, res){
    res.send("Customer Created");
});

app.update("/cust_update", function(req, res){
    res.send("Customer Update");
});

app.delete("cust_delete", function(req, res){
    res.send("Customer Delete");
});

var server= app.listen(3000, function(){
    var port = server.address().port;
    console.log("Server is running at Port No. "+ port);
});