// get the reference of EventEmitter class of events module
var events = require('events');
var fs=require('fs');
//create an object of EventEmitter class by using above reference
var em = new events.EventEmitter();

//Subscribe for FirstEvent -- adding listeners on or addListener()
em.on('FirstEvent', function (data) {
console.log('First subscriber: ' + data);
});
em.on('FirstEvent', function (data) {
console.log('Second subscriber: ' + data);
});
em.once('NewEvent',function(data)
{
	console.log(data);
});
em.on('status',function (code, msg)
{ 
	console.log('Got'+code+msg);
});
function c1()
{
	console.log("event listener removed");
}
em.on("error", function(error) 
{
    console.error(error);
});
fs.open('samplez.txt', 'r+', function(err, fd)
{ 
   if (err) { 
      em.emit("error","File not found");
   } 
});
fs.open('samplez1.txt', 'r+', function(err, fd)
{ 
   if (err) { 
      em.emit("error","File not found12");
   } 
});
// Raising FirstEvent
em.emit('FirstEvent', 'This is my first Node.js event emitter example.');
em.emit('FirstEvent', 'This is my Second Node.js event emitter example.');
em.emit('NewEvent',"my new event");
em.emit('NewEvent',"my new event");//this event will not be listened
em.emit('status',200,'OK');
em.off('status',c1);        
