var fs = require("fs");
// fs.open("myfile.txt", "w", function (err, file) {
//   if (err) throw err;
//   console.log("File is Saved");
// });

//Write adata to File!
// fs.writeFile("myfile.txt","Welcome Node JS",function(err)
// {
//     if(err)
//     throw err;
//     console.log("File is Written!");
// });

// fs.appendFile("myfile.txt","Angular JS",function(err){
//     if(err)
//     throw err;
//     console.log("File is appended!");
// })

// fs.rename("myfile.txt","yashcr.txt",function(err)
// {
//     if(err)
//     throw err;
//     console.log("File is renamed!");
// });

fs.unlink("yashcr.txt", function (err) {
  if (err) throw err;
  console.log("File is deleted!");
});