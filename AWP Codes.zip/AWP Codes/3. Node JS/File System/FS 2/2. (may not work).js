var fs = require("fs"); 

console.log("writing into existing file"); 
fs.writeFile('sample1.txt', 'This is node.js class', 'utf8',function(err) { 
   if (err)  
      return console.error(err); 
   }) 
     
   console.log("Data written successfully!"); 
var data2 = "\nWe are learning fs module"; 
   
// fs Append data to file 
fs.appendFile('sample1.txt', data2, 'utf8', function(err)
 {  
        if (err) throw err; 
      
        //  If no error 
        console.log("Data is appended to file successfully.") 
});   
  
// Asynchronous - Opening File 
console.log("opening file!"); 
fs.open('sample1.txt', 'r+', function(err, fd) { 
   if (err) { 
      return console.error(err); 
   }      

//var buf = new Buffer.alloc(1024); 
console.log("File opened successfully!"); 
console.log("reading the file"); 
     
   fs.readFile(fd, 'utf-8', function(err, data){ 
      if (err){ 
         console.log(err); 
      } 
      console.log(data); 
        
      // Print only read bytes to avoid junk. 
      /*if(bytes > 0){ 
         console.log(buf.slice(0, bytes).toString()); 
      } */
      //closing the file
      fs.close(fd, function(err) {
         if (err) {
            console.log(err);
         } 
         console.log("File closed successfully.");
      });
   });  //closing read
	
});//closing open
/*fs.unlink('sample_http.txt', function (err) {
  if (err) throw err;
  console.log('File deleted!');
});*/
