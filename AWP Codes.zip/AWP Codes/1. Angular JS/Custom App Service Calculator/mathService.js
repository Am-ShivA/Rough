app.service('mathService',function(){
    //this service will define a set of methods; add/sub/mult/div
    //all methods are using $scope object
    //all ?service? are accessed using this ?method?
    this.add=function(x,y){
        return parseInt(x)+parseInt(y);
    }
    this.mul=function(x,y){
        return parseInt(x)*parseInt(y);
    }
    this.div=function(x,y){
        return parseInt(x)/parseInt(y);
    }
    this.sub=function(x,y){
        return parseInt(x)-parseInt(y);
    }
});