app.service('taxService',function(){
    var income;
    this.tax=function(x,y){
       if (y<150000){
           income = x-y-50000;    // this income is net taxable income
           if (income<25000){
               return 'Nil';
            }
            
            if (income >= 25000 && income <500000){
                return 5*income/100;
            }
            if (income >= 500000 && income <= 1000000){
                return 20*income/100;
            }
            
            else if(income > 1000000){
                return 30*income/100;
            }
        }
        else{
            return "Value of deduction is too high. Please try again. "
        }
    } 
    }
)
