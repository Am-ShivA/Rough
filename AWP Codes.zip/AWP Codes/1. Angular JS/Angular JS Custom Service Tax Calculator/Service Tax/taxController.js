app.controller("taxController", function($scope, taxService){
    $scope.calc = function(){
        $scope.result = taxService.tax($scope.myIncome, $scope.myDeduction);
    }
});